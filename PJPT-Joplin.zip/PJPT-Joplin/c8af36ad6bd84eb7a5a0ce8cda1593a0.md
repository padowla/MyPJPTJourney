885e0a198141aac97247ed8f32693c67.png

id: c8af36ad6bd84eb7a5a0ce8cda1593a0
mime: image/png
filename: 
created_time: 2023-12-13T23:34:26.858Z
updated_time: 2023-12-13T23:34:26.858Z
user_created_time: 2023-12-13T23:34:26.858Z
user_updated_time: 2023-12-13T23:34:26.858Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 221648
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1702510466858
type_: 4